arr = [10, 20, 30, 40]
arr[1] = 30 # set element 1 (20) of array to 30
print(arr)
